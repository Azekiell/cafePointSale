package Main;

import Utilities.NoOrderFound;
import java.awt.Color;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class Menu extends javax.swing.JFrame {
    Connection conn = new Database.DBase().conn();
    DefaultTableModel table;
    DefaultTableModel table1;
    
    ArrayList<String> item = new ArrayList<String>();
    ArrayList<Integer> quantity = new ArrayList<Integer>();
    ArrayList<Double> price = new ArrayList<Double>();
    
    ImageIcon activeAdd = new ImageIcon(getClass().getResource("/Images/Icons/add_icon.png"));
    ImageIcon disabledAdd = new ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"));
    ImageIcon activeSubtract = new ImageIcon(getClass().getResource("/Images/Icons/subtract_icon.png"));
    ImageIcon disabledSubtract = new ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"));
    
    
    String paymentMethod = "cash";
    int totalPriceCheck = 0;
    DecimalFormat df = new DecimalFormat("#,##0.00");
    private String id = "0";
        
    public Menu() {
        initComponents();
        table = new DefaultTableModel(new String[]{"Item", "Price"}, 0);
        orders.setModel(table);
        
        table1 = new DefaultTableModel(new String[]{"Item", "Quantity", "Price"}, 0);
        ordersInfo.setModel(table1);
        finalMoney.setVisible(false);
    }
    
    public Menu(String id) {
        initComponents();
        this.id = id;
        table = new DefaultTableModel(new String[]{"Item", "Price"}, 0);
        orders.setModel(table);
        
        table1 = new DefaultTableModel(new String[]{"Item", "Quantity", "Price"}, 0);
        ordersInfo.setModel(table1);
        finalMoney.setVisible(false);
    }
    
    public void setItem(String item, double price, boolean isAdding){
        if(isAdding){
            if(this.item.contains(item)){
                int i = this.item.indexOf(item);
                this.price.set(i, this.price.get(i)+price);
                quantity.set(i, quantity.get(i)+1);
            }else{
                this.item.add(item);
                this.price.add(price);
                quantity.add(1);
            }
        }else{
            if(this.item.contains(item)){
                if(quantity.get(this.item.indexOf(item)) <= 1){
                    quantity.remove(this.item.indexOf(item));
                    this.price.remove(this.item.indexOf(item));
                    this.item.remove(item);
                }else{
                    int i = this.item.indexOf(item);
                    this.price.set(i, this.price.get(i)-price);
                    quantity.set(i, quantity.get(i)-1);
                }
            }
        }
    }

    public void setOrderTable(){
        table.setRowCount(0);
        int rowForCol1 = 0;
        for(String items : item){
            rowForCol1++;
            table.setRowCount(rowForCol1);
            table.setValueAt(items +" x " +quantity.get(rowForCol1-1), rowForCol1-1, 0);
            table.setValueAt(price.get(rowForCol1-1), rowForCol1-1, 1);
        }
    }
    
    public void setOrdersInfo(){
        table1.setRowCount(0);
        int rowForCol1 = 0;
        for(String items : item){
            rowForCol1++;
            table1.setRowCount(rowForCol1);
            table1.setValueAt(items, rowForCol1-1, 0);
            table1.setValueAt(quantity.get(rowForCol1-1), rowForCol1-1, 1);
            table1.setValueAt(price.get(rowForCol1-1)*quantity.get(rowForCol1-1), rowForCol1-1, 2);
            totalPriceCheck += price.get(rowForCol1-1)*quantity.get(rowForCol1-1);
        }
        totalCheck.setText(String.valueOf(totalPriceCheck));
    }
    
    public void setDiscount(double discount, String payMethod){
        String totalDiscountF = df.format(totalPriceCheck*discount);
        double totalDiscount = totalPriceCheck*discount;
        totalCheck.setText(String.valueOf(totalPriceCheck-totalDiscount));
        
        if(payMethod.equals("cash")){
            saved.setText("₱0 (0%)");
        }else if(payMethod.equals("gcash")){
            saved.setText("₱" +totalDiscountF +" (7%)");
        }else{
            saved.setText("₱" +totalDiscountF +" (5%)");
        }
    }
    
    public void addOrder(ArrayList<String> items, ArrayList<Integer> quantity, ArrayList<Double> price){
        String query = "INSERT INTO receipts VALUES ('"+id+"', ?, ?, ?, NOW());";
        int index = 0;
        try{
            PreparedStatement pst = conn.prepareStatement(query);
            for(String itm : items){
                index++;
                pst.setString(1, itm);
                pst.setInt(2, quantity.get(index-1));
                pst.setDouble(3, Double.parseDouble(String.valueOf(price.get(index-1)).replaceAll(",", "")));
                pst.execute();
            }
        }catch(Exception e){
            System.out.println(e);
            e.printStackTrace();
        }
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cappuccinoBtns = new javax.swing.ButtonGroup();
        americanoBtns = new javax.swing.ButtonGroup();
        espressoBtns = new javax.swing.ButtonGroup();
        cMacchiatoBtns = new javax.swing.ButtonGroup();
        iCoffeeBtns = new javax.swing.ButtonGroup();
        cCreamBtns = new javax.swing.ButtonGroup();
        dDelightBtns = new javax.swing.ButtonGroup();
        menuPanel = new javax.swing.JPanel();
        choicePanel = new javax.swing.JPanel();
        menuLabell = new javax.swing.JLabel();
        header = new javax.swing.JLabel();
        year = new javax.swing.JLabel();
        itemSelection = new javax.swing.JPanel();
        headerPriceSmall = new javax.swing.JLabel();
        headerPriceMedium = new javax.swing.JLabel();
        headerPriceLarge = new javax.swing.JLabel();
        Espresso = new javax.swing.JCheckBox();
        espressoSmallAdd = new javax.swing.JLabel();
        espressoSmallSubtract = new javax.swing.JLabel();
        espressoMediumAdd = new javax.swing.JLabel();
        espressoMediumSubtract = new javax.swing.JLabel();
        espresssoLargeAdd = new javax.swing.JLabel();
        espresssoLargeSubtract = new javax.swing.JLabel();
        espressoPriceSmall = new javax.swing.JLabel();
        espressoPriceMedium = new javax.swing.JLabel();
        espressoPriceLarge = new javax.swing.JLabel();
        Americano = new javax.swing.JCheckBox();
        americanoSmallAdd = new javax.swing.JLabel();
        americanoSmallSubtract = new javax.swing.JLabel();
        americanoPriceSmall = new javax.swing.JLabel();
        americanoMediumAdd = new javax.swing.JLabel();
        americanoMediumSubtract = new javax.swing.JLabel();
        americanoPriceMedium = new javax.swing.JLabel();
        americanoLargeAdd = new javax.swing.JLabel();
        americanoLargeSubtract = new javax.swing.JLabel();
        americanoPriceLarge = new javax.swing.JLabel();
        Cappuccino = new javax.swing.JCheckBox();
        cappuccinoSmallAdd = new javax.swing.JLabel();
        cappuccinoSmallSubtract = new javax.swing.JLabel();
        cappuccinoMediumAdd = new javax.swing.JLabel();
        cappuccinoMediumSubtract = new javax.swing.JLabel();
        cappuccinoPriceMedium = new javax.swing.JLabel();
        cappuccinoLargeAdd = new javax.swing.JLabel();
        cappuccinoLargeSubtract = new javax.swing.JLabel();
        cappuccinoPriceLarge = new javax.swing.JLabel();
        cappuccinoPriceSmall = new javax.swing.JLabel();
        Macchiato = new javax.swing.JCheckBox();
        macchiatoSmallAdd = new javax.swing.JLabel();
        macchiatoSmallSubtract = new javax.swing.JLabel();
        macchiatoPriceSmall = new javax.swing.JLabel();
        macchiatoMediumAdd = new javax.swing.JLabel();
        macchiatoMediumSubtract = new javax.swing.JLabel();
        macchiatoPriceMedium = new javax.swing.JLabel();
        macchiatoLargeAdd = new javax.swing.JLabel();
        macchiatoLargeSubtract = new javax.swing.JLabel();
        macchiatoPriceLarge = new javax.swing.JLabel();
        CaramelC = new javax.swing.JCheckBox();
        caramelCPriceLarge = new javax.swing.JLabel();
        caramelCSmallAdd = new javax.swing.JLabel();
        caramelCSmallSubtract = new javax.swing.JLabel();
        caramelCPriceSmall = new javax.swing.JLabel();
        caramelCMediumAdd = new javax.swing.JLabel();
        caramelCMediumSubtract = new javax.swing.JLabel();
        caramelCPriceMedium = new javax.swing.JLabel();
        caramelCLargeAdd = new javax.swing.JLabel();
        caramelCLargeSubtract = new javax.swing.JLabel();
        DecafD = new javax.swing.JCheckBox();
        decafDSmallAdd = new javax.swing.JLabel();
        decafDSmallSubtract = new javax.swing.JLabel();
        decafDPriceSmall = new javax.swing.JLabel();
        decafDMediumAdd = new javax.swing.JLabel();
        decafDMediumSubtract = new javax.swing.JLabel();
        decafDPriceMedium = new javax.swing.JLabel();
        decafDLargeAdd = new javax.swing.JLabel();
        decafDLargeSubtract = new javax.swing.JLabel();
        decafDPriceLarge = new javax.swing.JLabel();
        IcedCoffee = new javax.swing.JCheckBox();
        iceCoffeeSmallSubtract = new javax.swing.JLabel();
        iceCoffeePriceSmall = new javax.swing.JLabel();
        iceCoffeeSmallAdd = new javax.swing.JLabel();
        iceCoffeeMediumAdd = new javax.swing.JLabel();
        iceCoffeeMediumSubtract = new javax.swing.JLabel();
        iceCoffeePriceMedium = new javax.swing.JLabel();
        iceCoffeeLargeAdd = new javax.swing.JLabel();
        iceCoffeeLargeSubtract = new javax.swing.JLabel();
        iceCoffeePriceLarge = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        orders = new javax.swing.JTable();
        nextButton = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cheeseCake = new javax.swing.JLabel();
        cheeseCakeAdd = new javax.swing.JLabel();
        cheeseCakeSubtract = new javax.swing.JLabel();
        croissant = new javax.swing.JLabel();
        croissantAdd = new javax.swing.JLabel();
        croissantSubtract = new javax.swing.JLabel();
        brownies = new javax.swing.JLabel();
        browniesAdd = new javax.swing.JLabel();
        browniesSubtract = new javax.swing.JLabel();
        strawberryW = new javax.swing.JLabel();
        strawberryWAdd = new javax.swing.JLabel();
        strawberryWSubtract = new javax.swing.JLabel();
        chocoM = new javax.swing.JLabel();
        chocoMAdd = new javax.swing.JLabel();
        chocoMSubtract = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        backGround = new javax.swing.JLabel();
        orderPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ordersInfo = new javax.swing.JTable();
        confirm = new javax.swing.JButton();
        back = new javax.swing.JButton();
        selectPayment = new javax.swing.JPanel();
        money = new javax.swing.JTextField();
        cash = new javax.swing.JLabel();
        paymaya = new javax.swing.JLabel();
        gcash = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        finalMoney = new javax.swing.JPanel();
        takeOut = new javax.swing.JCheckBox();
        totalText = new javax.swing.JLabel();
        totalCheck = new javax.swing.JLabel();
        savedText = new javax.swing.JLabel();
        saved = new javax.swing.JLabel();
        confirm1 = new javax.swing.JButton();
        orderBg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(600, 539));
        setResizable(false);
        getContentPane().setLayout(new java.awt.CardLayout());

        choicePanel.setBackground(new java.awt.Color(255, 255, 255));
        choicePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuLabell.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        menuLabell.setForeground(new java.awt.Color(255, 153, 0));
        menuLabell.setText("Menu");
        choicePanel.add(menuLabell, new org.netbeans.lib.awtextra.AbsoluteConstraints(265, 90, 70, 20));

        header.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        header.setForeground(new java.awt.Color(255, 102, 0));
        header.setText("TnC Cafe");
        choicePanel.add(header, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        year.setForeground(new java.awt.Color(255, 255, 255));
        year.setText("Since 2024");
        choicePanel.add(year, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        itemSelection.setBackground(new java.awt.Color(0, 0, 0, 0));
        itemSelection.setOpaque(false);
        itemSelection.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        headerPriceSmall.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        headerPriceSmall.setForeground(new java.awt.Color(255, 102, 0));
        headerPriceSmall.setText("Small");
        itemSelection.add(headerPriceSmall, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 10, -1, -1));

        headerPriceMedium.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        headerPriceMedium.setForeground(new java.awt.Color(255, 102, 0));
        headerPriceMedium.setText("Medium");
        itemSelection.add(headerPriceMedium, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 10, -1, -1));

        headerPriceLarge.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        headerPriceLarge.setForeground(new java.awt.Color(255, 102, 0));
        headerPriceLarge.setText("Large");
        itemSelection.add(headerPriceLarge, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 10, -1, -1));

        Espresso.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        Espresso.setForeground(new java.awt.Color(255, 255, 255));
        Espresso.setText("Espresso");
        Espresso.setContentAreaFilled(false);
        Espresso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EspressoActionPerformed(evt);
            }
        });
        itemSelection.add(Espresso, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, -1, -1));

        espressoSmallAdd.setBackground(new java.awt.Color(0, 153, 0));
        espressoSmallAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        espressoSmallAdd.setForeground(new java.awt.Color(255, 255, 255));
        espressoSmallAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        espressoSmallAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        espressoSmallAdd.setOpaque(true);
        espressoSmallAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                espressoSmallAddMouseClicked(evt);
            }
        });
        itemSelection.add(espressoSmallAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 30, 15, 15));

        espressoSmallSubtract.setBackground(new java.awt.Color(204, 0, 0));
        espressoSmallSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        espressoSmallSubtract.setForeground(new java.awt.Color(255, 255, 255));
        espressoSmallSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        espressoSmallSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        espressoSmallSubtract.setOpaque(true);
        espressoSmallSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                espressoSmallSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(espressoSmallSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 30, 15, 15));

        espressoMediumAdd.setBackground(new java.awt.Color(0, 153, 0));
        espressoMediumAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        espressoMediumAdd.setForeground(new java.awt.Color(255, 255, 255));
        espressoMediumAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        espressoMediumAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        espressoMediumAdd.setOpaque(true);
        espressoMediumAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                espressoMediumAddMouseClicked(evt);
            }
        });
        itemSelection.add(espressoMediumAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 30, 15, 15));

        espressoMediumSubtract.setBackground(new java.awt.Color(204, 0, 0));
        espressoMediumSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        espressoMediumSubtract.setForeground(new java.awt.Color(255, 255, 255));
        espressoMediumSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        espressoMediumSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        espressoMediumSubtract.setOpaque(true);
        espressoMediumSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                espressoMediumSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(espressoMediumSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 30, 15, 15));

        espresssoLargeAdd.setBackground(new java.awt.Color(0, 153, 0));
        espresssoLargeAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        espresssoLargeAdd.setForeground(new java.awt.Color(255, 255, 255));
        espresssoLargeAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        espresssoLargeAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        espresssoLargeAdd.setOpaque(true);
        espresssoLargeAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                espresssoLargeAddMouseClicked(evt);
            }
        });
        itemSelection.add(espresssoLargeAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 30, 15, 15));

        espresssoLargeSubtract.setBackground(new java.awt.Color(204, 0, 0));
        espresssoLargeSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        espresssoLargeSubtract.setForeground(new java.awt.Color(255, 255, 255));
        espresssoLargeSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        espresssoLargeSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        espresssoLargeSubtract.setOpaque(true);
        espresssoLargeSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                espresssoLargeSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(espresssoLargeSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 30, 15, 15));

        espressoPriceSmall.setForeground(new java.awt.Color(255, 255, 255));
        espressoPriceSmall.setText("₱30.00");
        itemSelection.add(espressoPriceSmall, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 30, -1, -1));

        espressoPriceMedium.setForeground(new java.awt.Color(255, 255, 255));
        espressoPriceMedium.setText("₱45.00");
        itemSelection.add(espressoPriceMedium, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 30, -1, -1));

        espressoPriceLarge.setForeground(new java.awt.Color(255, 255, 255));
        espressoPriceLarge.setText("₱60.00");
        itemSelection.add(espressoPriceLarge, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 30, -1, -1));

        Americano.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        Americano.setForeground(new java.awt.Color(255, 255, 255));
        Americano.setText("Americano");
        Americano.setContentAreaFilled(false);
        Americano.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AmericanoActionPerformed(evt);
            }
        });
        itemSelection.add(Americano, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        americanoSmallAdd.setBackground(new java.awt.Color(0, 153, 0));
        americanoSmallAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        americanoSmallAdd.setForeground(new java.awt.Color(255, 255, 255));
        americanoSmallAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        americanoSmallAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        americanoSmallAdd.setOpaque(true);
        americanoSmallAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                americanoSmallAddMouseClicked(evt);
            }
        });
        itemSelection.add(americanoSmallAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 50, 15, 15));

        americanoSmallSubtract.setBackground(new java.awt.Color(204, 0, 0));
        americanoSmallSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        americanoSmallSubtract.setForeground(new java.awt.Color(255, 255, 255));
        americanoSmallSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        americanoSmallSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        americanoSmallSubtract.setOpaque(true);
        americanoSmallSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                americanoSmallSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(americanoSmallSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 50, 15, 15));

        americanoPriceSmall.setForeground(new java.awt.Color(255, 255, 255));
        americanoPriceSmall.setText("₱35.00");
        itemSelection.add(americanoPriceSmall, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, -1, -1));

        americanoMediumAdd.setBackground(new java.awt.Color(0, 153, 0));
        americanoMediumAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        americanoMediumAdd.setForeground(new java.awt.Color(255, 255, 255));
        americanoMediumAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        americanoMediumAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        americanoMediumAdd.setOpaque(true);
        americanoMediumAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                americanoMediumAddMouseClicked(evt);
            }
        });
        itemSelection.add(americanoMediumAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 50, 15, 15));

        americanoMediumSubtract.setBackground(new java.awt.Color(204, 0, 0));
        americanoMediumSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        americanoMediumSubtract.setForeground(new java.awt.Color(255, 255, 255));
        americanoMediumSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        americanoMediumSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        americanoMediumSubtract.setOpaque(true);
        americanoMediumSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                americanoMediumSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(americanoMediumSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 50, 15, 15));

        americanoPriceMedium.setForeground(new java.awt.Color(255, 255, 255));
        americanoPriceMedium.setText("₱45.00");
        itemSelection.add(americanoPriceMedium, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 50, -1, -1));

        americanoLargeAdd.setBackground(new java.awt.Color(0, 153, 0));
        americanoLargeAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        americanoLargeAdd.setForeground(new java.awt.Color(255, 255, 255));
        americanoLargeAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        americanoLargeAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        americanoLargeAdd.setOpaque(true);
        americanoLargeAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                americanoLargeAddMouseClicked(evt);
            }
        });
        itemSelection.add(americanoLargeAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 50, 15, 15));

        americanoLargeSubtract.setBackground(new java.awt.Color(204, 0, 0));
        americanoLargeSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        americanoLargeSubtract.setForeground(new java.awt.Color(255, 255, 255));
        americanoLargeSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        americanoLargeSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        americanoLargeSubtract.setOpaque(true);
        americanoLargeSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                americanoLargeSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(americanoLargeSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 50, 15, 15));

        americanoPriceLarge.setForeground(new java.awt.Color(255, 255, 255));
        americanoPriceLarge.setText("₱65.00");
        itemSelection.add(americanoPriceLarge, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 50, -1, -1));

        Cappuccino.setBackground(new java.awt.Color(51, 51, 51));
        Cappuccino.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        Cappuccino.setForeground(new java.awt.Color(255, 255, 255));
        Cappuccino.setText("Cappuccino");
        Cappuccino.setContentAreaFilled(false);
        Cappuccino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CappuccinoActionPerformed(evt);
            }
        });
        itemSelection.add(Cappuccino, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, -1, -1));

        cappuccinoSmallAdd.setBackground(new java.awt.Color(0, 153, 0));
        cappuccinoSmallAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cappuccinoSmallAdd.setForeground(new java.awt.Color(255, 255, 255));
        cappuccinoSmallAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cappuccinoSmallAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        cappuccinoSmallAdd.setOpaque(true);
        cappuccinoSmallAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cappuccinoSmallAddMouseClicked(evt);
            }
        });
        itemSelection.add(cappuccinoSmallAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 70, 15, 15));

        cappuccinoSmallSubtract.setBackground(new java.awt.Color(204, 0, 0));
        cappuccinoSmallSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cappuccinoSmallSubtract.setForeground(new java.awt.Color(255, 255, 255));
        cappuccinoSmallSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cappuccinoSmallSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        cappuccinoSmallSubtract.setOpaque(true);
        cappuccinoSmallSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cappuccinoSmallSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(cappuccinoSmallSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 70, 15, 15));

        cappuccinoMediumAdd.setBackground(new java.awt.Color(0, 153, 0));
        cappuccinoMediumAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cappuccinoMediumAdd.setForeground(new java.awt.Color(255, 255, 255));
        cappuccinoMediumAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cappuccinoMediumAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        cappuccinoMediumAdd.setOpaque(true);
        cappuccinoMediumAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cappuccinoMediumAddMouseClicked(evt);
            }
        });
        itemSelection.add(cappuccinoMediumAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 70, 15, 15));

        cappuccinoMediumSubtract.setBackground(new java.awt.Color(204, 0, 0));
        cappuccinoMediumSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cappuccinoMediumSubtract.setForeground(new java.awt.Color(255, 255, 255));
        cappuccinoMediumSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cappuccinoMediumSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        cappuccinoMediumSubtract.setOpaque(true);
        cappuccinoMediumSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cappuccinoMediumSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(cappuccinoMediumSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 70, 15, 15));

        cappuccinoPriceMedium.setForeground(new java.awt.Color(255, 255, 255));
        cappuccinoPriceMedium.setText("₱47.00");
        itemSelection.add(cappuccinoPriceMedium, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 70, -1, -1));

        cappuccinoLargeAdd.setBackground(new java.awt.Color(0, 153, 0));
        cappuccinoLargeAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cappuccinoLargeAdd.setForeground(new java.awt.Color(255, 255, 255));
        cappuccinoLargeAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cappuccinoLargeAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        cappuccinoLargeAdd.setOpaque(true);
        cappuccinoLargeAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cappuccinoLargeAddMouseClicked(evt);
            }
        });
        itemSelection.add(cappuccinoLargeAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 70, 15, 15));

        cappuccinoLargeSubtract.setBackground(new java.awt.Color(204, 0, 0));
        cappuccinoLargeSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cappuccinoLargeSubtract.setForeground(new java.awt.Color(255, 255, 255));
        cappuccinoLargeSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cappuccinoLargeSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        cappuccinoLargeSubtract.setOpaque(true);
        cappuccinoLargeSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cappuccinoLargeSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(cappuccinoLargeSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 70, 15, 15));

        cappuccinoPriceLarge.setForeground(new java.awt.Color(255, 255, 255));
        cappuccinoPriceLarge.setText("₱70.00");
        itemSelection.add(cappuccinoPriceLarge, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 70, -1, -1));

        cappuccinoPriceSmall.setForeground(new java.awt.Color(255, 255, 255));
        cappuccinoPriceSmall.setText("₱35.00");
        itemSelection.add(cappuccinoPriceSmall, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, -1, -1));

        Macchiato.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        Macchiato.setForeground(new java.awt.Color(255, 255, 255));
        Macchiato.setText("Caffe Macchiato");
        Macchiato.setContentAreaFilled(false);
        Macchiato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MacchiatoActionPerformed(evt);
            }
        });
        itemSelection.add(Macchiato, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, -1, -1));

        macchiatoSmallAdd.setBackground(new java.awt.Color(0, 153, 0));
        macchiatoSmallAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        macchiatoSmallAdd.setForeground(new java.awt.Color(255, 255, 255));
        macchiatoSmallAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        macchiatoSmallAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        macchiatoSmallAdd.setOpaque(true);
        macchiatoSmallAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                macchiatoSmallAddMouseClicked(evt);
            }
        });
        itemSelection.add(macchiatoSmallAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 90, 15, 15));

        macchiatoSmallSubtract.setBackground(new java.awt.Color(204, 0, 0));
        macchiatoSmallSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        macchiatoSmallSubtract.setForeground(new java.awt.Color(255, 255, 255));
        macchiatoSmallSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        macchiatoSmallSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        macchiatoSmallSubtract.setOpaque(true);
        macchiatoSmallSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                macchiatoSmallSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(macchiatoSmallSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 90, 15, 15));

        macchiatoPriceSmall.setForeground(new java.awt.Color(255, 255, 255));
        macchiatoPriceSmall.setText("₱40.00");
        itemSelection.add(macchiatoPriceSmall, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 90, -1, -1));

        macchiatoMediumAdd.setBackground(new java.awt.Color(0, 153, 0));
        macchiatoMediumAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        macchiatoMediumAdd.setForeground(new java.awt.Color(255, 255, 255));
        macchiatoMediumAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        macchiatoMediumAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        macchiatoMediumAdd.setOpaque(true);
        macchiatoMediumAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                macchiatoMediumAddMouseClicked(evt);
            }
        });
        itemSelection.add(macchiatoMediumAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 90, 15, 15));

        macchiatoMediumSubtract.setBackground(new java.awt.Color(204, 0, 0));
        macchiatoMediumSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        macchiatoMediumSubtract.setForeground(new java.awt.Color(255, 255, 255));
        macchiatoMediumSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        macchiatoMediumSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        macchiatoMediumSubtract.setOpaque(true);
        macchiatoMediumSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                macchiatoMediumSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(macchiatoMediumSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 90, 15, 15));

        macchiatoPriceMedium.setForeground(new java.awt.Color(255, 255, 255));
        macchiatoPriceMedium.setText("₱50.00");
        itemSelection.add(macchiatoPriceMedium, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 90, -1, -1));

        macchiatoLargeAdd.setBackground(new java.awt.Color(0, 153, 0));
        macchiatoLargeAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        macchiatoLargeAdd.setForeground(new java.awt.Color(255, 255, 255));
        macchiatoLargeAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        macchiatoLargeAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        macchiatoLargeAdd.setOpaque(true);
        macchiatoLargeAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                macchiatoLargeAddMouseClicked(evt);
            }
        });
        itemSelection.add(macchiatoLargeAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 90, 15, 15));

        macchiatoLargeSubtract.setBackground(new java.awt.Color(204, 0, 0));
        macchiatoLargeSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        macchiatoLargeSubtract.setForeground(new java.awt.Color(255, 255, 255));
        macchiatoLargeSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        macchiatoLargeSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        macchiatoLargeSubtract.setOpaque(true);
        macchiatoLargeSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                macchiatoLargeSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(macchiatoLargeSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 90, 15, 15));

        macchiatoPriceLarge.setForeground(new java.awt.Color(255, 255, 255));
        macchiatoPriceLarge.setText("₱75.00");
        itemSelection.add(macchiatoPriceLarge, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 90, -1, -1));

        CaramelC.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        CaramelC.setForeground(new java.awt.Color(255, 255, 255));
        CaramelC.setText("Caramel Cream");
        CaramelC.setContentAreaFilled(false);
        CaramelC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CaramelCActionPerformed(evt);
            }
        });
        itemSelection.add(CaramelC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, -1, -1));

        caramelCPriceLarge.setForeground(new java.awt.Color(255, 255, 255));
        caramelCPriceLarge.setText("₱75.00");
        itemSelection.add(caramelCPriceLarge, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 110, -1, -1));

        caramelCSmallAdd.setBackground(new java.awt.Color(0, 153, 0));
        caramelCSmallAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        caramelCSmallAdd.setForeground(new java.awt.Color(255, 255, 255));
        caramelCSmallAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        caramelCSmallAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        caramelCSmallAdd.setOpaque(true);
        caramelCSmallAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                caramelCSmallAddMouseClicked(evt);
            }
        });
        itemSelection.add(caramelCSmallAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 110, 15, 15));

        caramelCSmallSubtract.setBackground(new java.awt.Color(204, 0, 0));
        caramelCSmallSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        caramelCSmallSubtract.setForeground(new java.awt.Color(255, 255, 255));
        caramelCSmallSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        caramelCSmallSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        caramelCSmallSubtract.setOpaque(true);
        caramelCSmallSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                caramelCSmallSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(caramelCSmallSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 110, 15, 15));

        caramelCPriceSmall.setForeground(new java.awt.Color(255, 255, 255));
        caramelCPriceSmall.setText("₱40.00");
        itemSelection.add(caramelCPriceSmall, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 110, -1, -1));

        caramelCMediumAdd.setBackground(new java.awt.Color(0, 153, 0));
        caramelCMediumAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        caramelCMediumAdd.setForeground(new java.awt.Color(255, 255, 255));
        caramelCMediumAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        caramelCMediumAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        caramelCMediumAdd.setOpaque(true);
        caramelCMediumAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                caramelCMediumAddMouseClicked(evt);
            }
        });
        itemSelection.add(caramelCMediumAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 110, 15, 15));

        caramelCMediumSubtract.setBackground(new java.awt.Color(204, 0, 0));
        caramelCMediumSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        caramelCMediumSubtract.setForeground(new java.awt.Color(255, 255, 255));
        caramelCMediumSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        caramelCMediumSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        caramelCMediumSubtract.setOpaque(true);
        caramelCMediumSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                caramelCMediumSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(caramelCMediumSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 110, 15, 15));

        caramelCPriceMedium.setForeground(new java.awt.Color(255, 255, 255));
        caramelCPriceMedium.setText("₱50.00");
        itemSelection.add(caramelCPriceMedium, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 110, -1, -1));

        caramelCLargeAdd.setBackground(new java.awt.Color(0, 153, 0));
        caramelCLargeAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        caramelCLargeAdd.setForeground(new java.awt.Color(255, 255, 255));
        caramelCLargeAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        caramelCLargeAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        caramelCLargeAdd.setOpaque(true);
        caramelCLargeAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                caramelCLargeAddMouseClicked(evt);
            }
        });
        itemSelection.add(caramelCLargeAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 110, 15, 15));

        caramelCLargeSubtract.setBackground(new java.awt.Color(204, 0, 0));
        caramelCLargeSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        caramelCLargeSubtract.setForeground(new java.awt.Color(255, 255, 255));
        caramelCLargeSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        caramelCLargeSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        caramelCLargeSubtract.setOpaque(true);
        caramelCLargeSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                caramelCLargeSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(caramelCLargeSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 110, 15, 15));

        DecafD.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        DecafD.setForeground(new java.awt.Color(255, 255, 255));
        DecafD.setText("Decaf Delight");
        DecafD.setContentAreaFilled(false);
        DecafD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DecafDActionPerformed(evt);
            }
        });
        itemSelection.add(DecafD, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        decafDSmallAdd.setBackground(new java.awt.Color(0, 153, 0));
        decafDSmallAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        decafDSmallAdd.setForeground(new java.awt.Color(255, 255, 255));
        decafDSmallAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        decafDSmallAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        decafDSmallAdd.setOpaque(true);
        decafDSmallAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                decafDSmallAddMouseClicked(evt);
            }
        });
        itemSelection.add(decafDSmallAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 130, 15, 15));

        decafDSmallSubtract.setBackground(new java.awt.Color(204, 0, 0));
        decafDSmallSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        decafDSmallSubtract.setForeground(new java.awt.Color(255, 255, 255));
        decafDSmallSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        decafDSmallSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        decafDSmallSubtract.setOpaque(true);
        decafDSmallSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                decafDSmallSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(decafDSmallSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 130, 15, 15));

        decafDPriceSmall.setForeground(new java.awt.Color(255, 255, 255));
        decafDPriceSmall.setText("₱45.00");
        itemSelection.add(decafDPriceSmall, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 130, -1, -1));

        decafDMediumAdd.setBackground(new java.awt.Color(0, 153, 0));
        decafDMediumAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        decafDMediumAdd.setForeground(new java.awt.Color(255, 255, 255));
        decafDMediumAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        decafDMediumAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        decafDMediumAdd.setOpaque(true);
        decafDMediumAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                decafDMediumAddMouseClicked(evt);
            }
        });
        itemSelection.add(decafDMediumAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 130, 15, 15));

        decafDMediumSubtract.setBackground(new java.awt.Color(204, 0, 0));
        decafDMediumSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        decafDMediumSubtract.setForeground(new java.awt.Color(255, 255, 255));
        decafDMediumSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        decafDMediumSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        decafDMediumSubtract.setOpaque(true);
        decafDMediumSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                decafDMediumSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(decafDMediumSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 130, 15, 15));

        decafDPriceMedium.setForeground(new java.awt.Color(255, 255, 255));
        decafDPriceMedium.setText("₱65.00");
        itemSelection.add(decafDPriceMedium, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 130, -1, -1));

        decafDLargeAdd.setBackground(new java.awt.Color(0, 153, 0));
        decafDLargeAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        decafDLargeAdd.setForeground(new java.awt.Color(255, 255, 255));
        decafDLargeAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        decafDLargeAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        decafDLargeAdd.setOpaque(true);
        decafDLargeAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                decafDLargeAddMouseClicked(evt);
            }
        });
        itemSelection.add(decafDLargeAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 130, 15, 15));

        decafDLargeSubtract.setBackground(new java.awt.Color(204, 0, 0));
        decafDLargeSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        decafDLargeSubtract.setForeground(new java.awt.Color(255, 255, 255));
        decafDLargeSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        decafDLargeSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        decafDLargeSubtract.setOpaque(true);
        decafDLargeSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                decafDLargeSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(decafDLargeSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 130, 15, 15));

        decafDPriceLarge.setForeground(new java.awt.Color(255, 255, 255));
        decafDPriceLarge.setText("₱105.00");
        itemSelection.add(decafDPriceLarge, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 130, -1, -1));

        IcedCoffee.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        IcedCoffee.setForeground(new java.awt.Color(255, 255, 255));
        IcedCoffee.setText("Iced Coffee");
        IcedCoffee.setContentAreaFilled(false);
        IcedCoffee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IcedCoffeeActionPerformed(evt);
            }
        });
        itemSelection.add(IcedCoffee, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        iceCoffeeSmallSubtract.setBackground(new java.awt.Color(204, 0, 0));
        iceCoffeeSmallSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        iceCoffeeSmallSubtract.setForeground(new java.awt.Color(255, 255, 255));
        iceCoffeeSmallSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iceCoffeeSmallSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        iceCoffeeSmallSubtract.setOpaque(true);
        iceCoffeeSmallSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iceCoffeeSmallSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(iceCoffeeSmallSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 150, 15, 15));

        iceCoffeePriceSmall.setForeground(new java.awt.Color(255, 255, 255));
        iceCoffeePriceSmall.setText("₱50.00");
        itemSelection.add(iceCoffeePriceSmall, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, -1, -1));

        iceCoffeeSmallAdd.setBackground(new java.awt.Color(0, 153, 0));
        iceCoffeeSmallAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        iceCoffeeSmallAdd.setForeground(new java.awt.Color(255, 255, 255));
        iceCoffeeSmallAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iceCoffeeSmallAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        iceCoffeeSmallAdd.setOpaque(true);
        iceCoffeeSmallAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iceCoffeeSmallAddMouseClicked(evt);
            }
        });
        itemSelection.add(iceCoffeeSmallAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 150, 15, 15));

        iceCoffeeMediumAdd.setBackground(new java.awt.Color(0, 153, 0));
        iceCoffeeMediumAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        iceCoffeeMediumAdd.setForeground(new java.awt.Color(255, 255, 255));
        iceCoffeeMediumAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iceCoffeeMediumAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        iceCoffeeMediumAdd.setOpaque(true);
        iceCoffeeMediumAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iceCoffeeMediumAddMouseClicked(evt);
            }
        });
        itemSelection.add(iceCoffeeMediumAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 150, 15, 15));

        iceCoffeeMediumSubtract.setBackground(new java.awt.Color(204, 0, 0));
        iceCoffeeMediumSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        iceCoffeeMediumSubtract.setForeground(new java.awt.Color(255, 255, 255));
        iceCoffeeMediumSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iceCoffeeMediumSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        iceCoffeeMediumSubtract.setOpaque(true);
        iceCoffeeMediumSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iceCoffeeMediumSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(iceCoffeeMediumSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 150, 15, 15));

        iceCoffeePriceMedium.setForeground(new java.awt.Color(255, 255, 255));
        iceCoffeePriceMedium.setText("₱75.00");
        itemSelection.add(iceCoffeePriceMedium, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 150, -1, -1));

        iceCoffeeLargeAdd.setBackground(new java.awt.Color(0, 153, 0));
        iceCoffeeLargeAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        iceCoffeeLargeAdd.setForeground(new java.awt.Color(255, 255, 255));
        iceCoffeeLargeAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iceCoffeeLargeAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_add_icon.png"))); // NOI18N
        iceCoffeeLargeAdd.setOpaque(true);
        iceCoffeeLargeAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iceCoffeeLargeAddMouseClicked(evt);
            }
        });
        itemSelection.add(iceCoffeeLargeAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 150, 15, 15));

        iceCoffeeLargeSubtract.setBackground(new java.awt.Color(204, 0, 0));
        iceCoffeeLargeSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        iceCoffeeLargeSubtract.setForeground(new java.awt.Color(255, 255, 255));
        iceCoffeeLargeSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        iceCoffeeLargeSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/disabled_subtract_icon.png"))); // NOI18N
        iceCoffeeLargeSubtract.setOpaque(true);
        iceCoffeeLargeSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iceCoffeeLargeSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(iceCoffeeLargeSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 150, 15, 15));

        iceCoffeePriceLarge.setForeground(new java.awt.Color(255, 255, 255));
        iceCoffeePriceLarge.setText("₱125.00");
        itemSelection.add(iceCoffeePriceLarge, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 150, -1, -1));

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setViewportView(null);

        orders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane2.setViewportView(orders);

        itemSelection.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 200, 300, 100));

        nextButton.setBackground(new java.awt.Color(255, 51, 0));
        nextButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        nextButton.setForeground(new java.awt.Color(255, 255, 255));
        nextButton.setText("Next");
        nextButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                nextButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                nextButtonMouseExited(evt);
            }
        });
        nextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextButtonActionPerformed(evt);
            }
        });
        itemSelection.add(nextButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 310, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 153, 0));
        jLabel6.setText("Foods");
        itemSelection.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 153, 0));
        jLabel5.setText("Coffee");
        itemSelection.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        cheeseCake.setForeground(new java.awt.Color(255, 255, 255));
        cheeseCake.setText("Cheesecake");
        itemSelection.add(cheeseCake, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 200, -1, -1));

        cheeseCakeAdd.setBackground(new java.awt.Color(0, 153, 0));
        cheeseCakeAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cheeseCakeAdd.setForeground(new java.awt.Color(255, 255, 255));
        cheeseCakeAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cheeseCakeAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/add_icon.png"))); // NOI18N
        cheeseCakeAdd.setOpaque(true);
        cheeseCakeAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cheeseCakeAddMouseClicked(evt);
            }
        });
        itemSelection.add(cheeseCakeAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 15, 15));

        cheeseCakeSubtract.setBackground(new java.awt.Color(204, 0, 0));
        cheeseCakeSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cheeseCakeSubtract.setForeground(new java.awt.Color(255, 255, 255));
        cheeseCakeSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cheeseCakeSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/subtract_icon.png"))); // NOI18N
        cheeseCakeSubtract.setOpaque(true);
        cheeseCakeSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cheeseCakeSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(cheeseCakeSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, 15, 15));

        croissant.setForeground(new java.awt.Color(255, 255, 255));
        croissant.setText("Croissant");
        itemSelection.add(croissant, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 220, -1, -1));

        croissantAdd.setBackground(new java.awt.Color(0, 153, 0));
        croissantAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        croissantAdd.setForeground(new java.awt.Color(255, 255, 255));
        croissantAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        croissantAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/add_icon.png"))); // NOI18N
        croissantAdd.setOpaque(true);
        croissantAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                croissantAddMouseClicked(evt);
            }
        });
        itemSelection.add(croissantAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, 15, 15));

        croissantSubtract.setBackground(new java.awt.Color(204, 0, 0));
        croissantSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        croissantSubtract.setForeground(new java.awt.Color(255, 255, 255));
        croissantSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        croissantSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/subtract_icon.png"))); // NOI18N
        croissantSubtract.setOpaque(true);
        croissantSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                croissantSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(croissantSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, 15, 15));

        brownies.setForeground(new java.awt.Color(255, 255, 255));
        brownies.setText("Brownies");
        itemSelection.add(brownies, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 240, -1, -1));

        browniesAdd.setBackground(new java.awt.Color(0, 153, 0));
        browniesAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        browniesAdd.setForeground(new java.awt.Color(255, 255, 255));
        browniesAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        browniesAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/add_icon.png"))); // NOI18N
        browniesAdd.setOpaque(true);
        browniesAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                browniesAddMouseClicked(evt);
            }
        });
        itemSelection.add(browniesAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, 15, 15));

        browniesSubtract.setBackground(new java.awt.Color(204, 0, 0));
        browniesSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        browniesSubtract.setForeground(new java.awt.Color(255, 255, 255));
        browniesSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        browniesSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/subtract_icon.png"))); // NOI18N
        browniesSubtract.setOpaque(true);
        browniesSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                browniesSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(browniesSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, 15, 15));

        strawberryW.setForeground(new java.awt.Color(255, 255, 255));
        strawberryW.setText("Strawberry Waffle");
        itemSelection.add(strawberryW, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 260, -1, -1));

        strawberryWAdd.setBackground(new java.awt.Color(0, 153, 0));
        strawberryWAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        strawberryWAdd.setForeground(new java.awt.Color(255, 255, 255));
        strawberryWAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        strawberryWAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/add_icon.png"))); // NOI18N
        strawberryWAdd.setOpaque(true);
        strawberryWAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                strawberryWAddMouseClicked(evt);
            }
        });
        itemSelection.add(strawberryWAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 15, 15));

        strawberryWSubtract.setBackground(new java.awt.Color(204, 0, 0));
        strawberryWSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        strawberryWSubtract.setForeground(new java.awt.Color(255, 255, 255));
        strawberryWSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        strawberryWSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/subtract_icon.png"))); // NOI18N
        strawberryWSubtract.setOpaque(true);
        strawberryWSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                strawberryWSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(strawberryWSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, 15, 15));

        chocoM.setForeground(new java.awt.Color(255, 255, 255));
        chocoM.setText("Chocolate Muffin");
        itemSelection.add(chocoM, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 280, -1, -1));

        chocoMAdd.setBackground(new java.awt.Color(0, 153, 0));
        chocoMAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        chocoMAdd.setForeground(new java.awt.Color(255, 255, 255));
        chocoMAdd.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        chocoMAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/add_icon.png"))); // NOI18N
        chocoMAdd.setOpaque(true);
        chocoMAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chocoMAddMouseClicked(evt);
            }
        });
        itemSelection.add(chocoMAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 15, 15));

        chocoMSubtract.setBackground(new java.awt.Color(204, 0, 0));
        chocoMSubtract.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        chocoMSubtract.setForeground(new java.awt.Color(255, 255, 255));
        chocoMSubtract.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        chocoMSubtract.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/subtract_icon.png"))); // NOI18N
        chocoMSubtract.setOpaque(true);
        chocoMSubtract.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                chocoMSubtractMouseClicked(evt);
            }
        });
        itemSelection.add(chocoMSubtract, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, 15, 15));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("₱50.00");
        itemSelection.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, -1, -1));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("₱55.00");
        itemSelection.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, -1, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("₱65.00");
        itemSelection.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 240, -1, -1));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("₱75.00");
        itemSelection.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, -1, -1));

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("₱99.00");
        itemSelection.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 280, -1, -1));

        choicePanel.add(itemSelection, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 600, 350));

        backGround.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Backgrounds/Menu.jpg"))); // NOI18N
        choicePanel.add(backGround, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 500));

        orderPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        ordersInfo.setBackground(new java.awt.Color(255, 102, 0));
        ordersInfo.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        ordersInfo.setForeground(new java.awt.Color(0, 0, 0));
        ordersInfo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null}
            },
            new String [] {
                "Item", "Quantity", "Total Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        ordersInfo.setGridColor(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(ordersInfo);

        orderPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 500, 130));

        confirm.setBackground(new java.awt.Color(255, 51, 0));
        confirm.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        confirm.setForeground(new java.awt.Color(255, 255, 255));
        confirm.setText("Confirm");
        confirm.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.white, new java.awt.Color(255, 51, 0), java.awt.Color.darkGray, java.awt.Color.black));
        confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmActionPerformed(evt);
            }
        });
        orderPanel.add(confirm, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 420, 70, -1));

        back.setBackground(new java.awt.Color(255, 51, 0));
        back.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back.setForeground(new java.awt.Color(255, 255, 255));
        back.setText("Add item");
        back.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.white, new java.awt.Color(255, 51, 0), java.awt.Color.darkGray, java.awt.Color.black));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        orderPanel.add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, 70, -1));

        selectPayment.setBackground(new java.awt.Color(0, 0, 0, 150));

        money.setForeground(new java.awt.Color(102, 102, 102));
        money.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        money.setText("Enter Money");
        money.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                moneyFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                moneyFocusLost(evt);
            }
        });

        cash.setForeground(new java.awt.Color(255, 255, 255));
        cash.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cash.setText("Cash");
        cash.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 0)));
        cash.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cashMouseClicked(evt);
            }
        });

        paymaya.setForeground(new java.awt.Color(255, 255, 255));
        paymaya.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        paymaya.setText("Paymaya");
        paymaya.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                paymayaMouseClicked(evt);
            }
        });

        gcash.setForeground(new java.awt.Color(255, 255, 255));
        gcash.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        gcash.setText("Gcash");
        gcash.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                gcashMouseClicked(evt);
            }
        });

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Payment Method");
        jLabel4.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));

        takeOut.setForeground(new java.awt.Color(0, 0, 0));
        takeOut.setText("Take out");
        takeOut.setContentAreaFilled(false);
        takeOut.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        takeOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                takeOutActionPerformed(evt);
            }
        });

        totalText.setForeground(new java.awt.Color(0, 0, 0));
        totalText.setText("Total:");

        totalCheck.setForeground(new java.awt.Color(0, 0, 0));

        savedText.setForeground(new java.awt.Color(0, 0, 0));
        savedText.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        savedText.setText("Saved: ");
        savedText.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 1, 0, 0, new java.awt.Color(0, 0, 0)));

        saved.setForeground(new java.awt.Color(0, 0, 0));
        saved.setText("₱0 (0%)");

        javax.swing.GroupLayout finalMoneyLayout = new javax.swing.GroupLayout(finalMoney);
        finalMoney.setLayout(finalMoneyLayout);
        finalMoneyLayout.setHorizontalGroup(
            finalMoneyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, finalMoneyLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(totalText)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(totalCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(savedText, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(saved, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(takeOut)
                .addContainerGap())
        );
        finalMoneyLayout.setVerticalGroup(
            finalMoneyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(finalMoneyLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(finalMoneyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(saved, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(finalMoneyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(totalText)
                        .addComponent(totalCheck, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(savedText)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, finalMoneyLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(takeOut)
                .addContainerGap())
        );

        javax.swing.GroupLayout selectPaymentLayout = new javax.swing.GroupLayout(selectPayment);
        selectPayment.setLayout(selectPaymentLayout);
        selectPaymentLayout.setHorizontalGroup(
            selectPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, selectPaymentLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(money, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(114, 114, 114))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, selectPaymentLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(selectPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(selectPaymentLayout.createSequentialGroup()
                        .addComponent(cash, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(gcash, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(paymaya, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(26, 26, 26))
            .addComponent(finalMoney, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        selectPaymentLayout.setVerticalGroup(
            selectPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, selectPaymentLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(money, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(selectPaymentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cash, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gcash, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(paymaya, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addComponent(finalMoney, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        orderPanel.add(selectPayment, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 210, 400, 160));

        confirm1.setBackground(new java.awt.Color(255, 51, 0));
        confirm1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        confirm1.setForeground(new java.awt.Color(255, 255, 255));
        confirm1.setText("Remove Item");
        confirm1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.white, new java.awt.Color(255, 51, 0), java.awt.Color.darkGray, java.awt.Color.black));
        confirm1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                confirm1MouseClicked(evt);
            }
        });
        confirm1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirm1ActionPerformed(evt);
            }
        });
        orderPanel.add(confirm1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 180, 90, -1));

        orderBg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Backgrounds/Order.jpg"))); // NOI18N
        orderPanel.add(orderBg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout menuPanelLayout = new javax.swing.GroupLayout(menuPanel);
        menuPanel.setLayout(menuPanelLayout);
        menuPanelLayout.setHorizontalGroup(
            menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 598, Short.MAX_VALUE)
            .addGroup(menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(menuPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(choicePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 598, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(menuPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(orderPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 598, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        menuPanelLayout.setVerticalGroup(
            menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
            .addGroup(menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(menuPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(choicePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(menuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(menuPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(orderPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        getContentPane().add(menuPanel, "card4");

        setSize(new java.awt.Dimension(614, 508));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void EspressoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EspressoActionPerformed
        if(Espresso.isSelected()){
            espressoSmallAdd.setIcon(activeAdd);
            espressoMediumAdd.setIcon(activeAdd);
            espresssoLargeAdd.setIcon(activeAdd);
            espressoSmallSubtract.setIcon(activeSubtract);
            espressoMediumSubtract.setIcon(activeSubtract);
            espresssoLargeSubtract.setIcon(activeSubtract);
        }else{
            espressoSmallAdd.setIcon(disabledAdd);
            espressoMediumAdd.setIcon(disabledAdd);
            espresssoLargeAdd.setIcon(disabledAdd);
            espressoSmallSubtract.setIcon(disabledSubtract);
            espressoMediumSubtract.setIcon(disabledSubtract);
            espresssoLargeSubtract.setIcon(disabledSubtract);
        }
    }//GEN-LAST:event_EspressoActionPerformed

    private void nextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextButtonActionPerformed
        if(item.isEmpty()){
            NoOrderFound e = new NoOrderFound(null, true);
            e.show();
        }else{
            finalMoney.setVisible(true);
            menuPanel.removeAll();
            menuPanel.add(orderPanel);
            menuPanel.repaint();
            menuPanel.revalidate();
            setOrdersInfo();
        }
    }//GEN-LAST:event_nextButtonActionPerformed

    private void espressoSmallSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_espressoSmallSubtractMouseClicked
        if(Espresso.isSelected()){
            setItem("Espresso S", 30.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_espressoSmallSubtractMouseClicked

    private void espressoSmallAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_espressoSmallAddMouseClicked
        if(Espresso.isSelected()) {
            setItem("Espresso S", 30.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_espressoSmallAddMouseClicked

    private void americanoSmallAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_americanoSmallAddMouseClicked
        if(Americano.isSelected()) {
            setItem("Americano S", 35.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_americanoSmallAddMouseClicked

    private void americanoSmallSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_americanoSmallSubtractMouseClicked
        if(Americano.isSelected()) {
            setItem("Americano S", 35.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_americanoSmallSubtractMouseClicked

    private void cappuccinoSmallAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cappuccinoSmallAddMouseClicked
        if(Cappuccino.isSelected()) {
            setItem("Cappuccino S", 35.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_cappuccinoSmallAddMouseClicked

    private void cappuccinoSmallSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cappuccinoSmallSubtractMouseClicked
        if(Cappuccino.isSelected()) {
            setItem("Cappuccino S", 35.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_cappuccinoSmallSubtractMouseClicked

    private void macchiatoSmallAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_macchiatoSmallAddMouseClicked
        if(Macchiato.isSelected()) {
            setItem("Caffe Macchiato S", 40.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_macchiatoSmallAddMouseClicked

    private void macchiatoSmallSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_macchiatoSmallSubtractMouseClicked
        if(Macchiato.isSelected()) {
            setItem("Caffe Macchiato S", 40.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_macchiatoSmallSubtractMouseClicked

    private void caramelCSmallAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_caramelCSmallAddMouseClicked
        if(CaramelC.isSelected()) {
            setItem("Caramel Cream S", 40.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_caramelCSmallAddMouseClicked

    private void caramelCSmallSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_caramelCSmallSubtractMouseClicked
        if(CaramelC.isSelected()) {
            setItem("Caramel Cream S", 40.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_caramelCSmallSubtractMouseClicked

    private void decafDSmallAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_decafDSmallAddMouseClicked
        if(DecafD.isSelected()) {
            setItem("Decaf Delight S", 45.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_decafDSmallAddMouseClicked

    private void decafDSmallSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_decafDSmallSubtractMouseClicked
        if(DecafD.isSelected()) {
            setItem("Decaf Delight S", 45.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_decafDSmallSubtractMouseClicked

    private void iceCoffeeSmallSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iceCoffeeSmallSubtractMouseClicked
        if(IcedCoffee.isSelected()) {
            setItem("Iced Coffee S", 50.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_iceCoffeeSmallSubtractMouseClicked

    private void iceCoffeeSmallAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iceCoffeeSmallAddMouseClicked
        if(IcedCoffee.isSelected()) {
            setItem("Iced Coffee S", 50.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_iceCoffeeSmallAddMouseClicked

    private void espressoMediumAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_espressoMediumAddMouseClicked
        if(Espresso.isSelected()){
            setItem("Espresso M", 45.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_espressoMediumAddMouseClicked

    private void nextButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nextButtonMouseEntered
        if(item.isEmpty()){
            nextButton.setBackground(Color.red);
        }else{
            nextButton.setBackground(Color.green);
        }
    }//GEN-LAST:event_nextButtonMouseEntered

    private void nextButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nextButtonMouseExited
        nextButton.setBackground(new Color(0xFF3300));
    }//GEN-LAST:event_nextButtonMouseExited

    private void confirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmActionPerformed
        String moneyy = money.getText();
        
        if(moneyy.matches("\\d{1,}")){
            if(Double.parseDouble(moneyy) >= Double.parseDouble(totalCheck.getText())){
                this.dispose();
                addOrder(item, quantity, price);
                Reciept r = new Reciept(null, true, item, quantity, price, moneyy, totalCheck.getText(), takeOut.isSelected());
                r.show();
            }else{
                JOptionPane.showMessageDialog(this, "Insuffecient Money!", "Error Money", JOptionPane.ERROR_MESSAGE);
            }
        }else{
            JOptionPane.showMessageDialog(this, "Please Enter A Valid Amount!", "Invalid Money", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_confirmActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        menuPanel.removeAll();
        menuPanel.add(choicePanel);
        menuPanel.repaint();
        menuPanel.revalidate();
    }//GEN-LAST:event_backActionPerformed

    private void moneyFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_moneyFocusGained
        if(money.getText().equals("Enter Money")){
            money.setText("");
            money.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_moneyFocusGained

    private void moneyFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_moneyFocusLost
        if(money.getText().isEmpty()){
            money.setText("Enter Money");
            money.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_moneyFocusLost

    private void cashMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cashMouseClicked
        paymentMethod = "cash";
        cash.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 0)));
        gcash.setBorder(null);
        paymaya.setBorder(null);
        setDiscount(0, "cash");
        menuPanel.repaint();
        menuPanel.revalidate();
    }//GEN-LAST:event_cashMouseClicked

    private void gcashMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_gcashMouseClicked
        paymentMethod = "gcash";
        gcash.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 0)));
        cash.setBorder(null);
        paymaya.setBorder(null);
        setDiscount(0.07, "gcash");
        menuPanel.repaint();
        menuPanel.revalidate();
    }//GEN-LAST:event_gcashMouseClicked

    private void paymayaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paymayaMouseClicked
        paymentMethod = "paymaya";
        paymaya.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 255, 0)));
        cash.setBorder(null);
        gcash.setBorder(null);
        setDiscount(0.05, "paymaya");
        menuPanel.repaint();
        menuPanel.revalidate();
    }//GEN-LAST:event_paymayaMouseClicked

    private void takeOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_takeOutActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_takeOutActionPerformed

    private void AmericanoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AmericanoActionPerformed
        if(Americano.isSelected()){
            americanoSmallAdd.setIcon(activeAdd);
            americanoMediumAdd.setIcon(activeAdd);
            americanoLargeAdd.setIcon(activeAdd);
            americanoSmallSubtract.setIcon(activeSubtract);
            americanoMediumSubtract.setIcon(activeSubtract);
            americanoLargeSubtract.setIcon(activeSubtract);
        }else{
            americanoSmallAdd.setIcon(disabledAdd);
            americanoMediumAdd.setIcon(disabledAdd);
            americanoLargeAdd.setIcon(disabledAdd);
            americanoSmallSubtract.setIcon(disabledSubtract);
            americanoMediumSubtract.setIcon(disabledSubtract);
            americanoLargeSubtract.setIcon(disabledSubtract);
        }
    }//GEN-LAST:event_AmericanoActionPerformed

    private void CappuccinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CappuccinoActionPerformed
        if(Cappuccino.isSelected()){
            cappuccinoSmallAdd.setIcon(activeAdd);
            cappuccinoMediumAdd.setIcon(activeAdd);
            cappuccinoLargeAdd.setIcon(activeAdd);
            cappuccinoSmallSubtract.setIcon(activeSubtract);
            cappuccinoMediumSubtract.setIcon(activeSubtract);
            cappuccinoLargeSubtract.setIcon(activeSubtract);
        }else{
            cappuccinoSmallAdd.setIcon(disabledAdd);
            cappuccinoMediumAdd.setIcon(disabledAdd);
            cappuccinoLargeAdd.setIcon(disabledAdd);
            cappuccinoSmallSubtract.setIcon(disabledSubtract);
            cappuccinoMediumSubtract.setIcon(disabledSubtract);
            cappuccinoLargeSubtract.setIcon(disabledSubtract);
        }
    }//GEN-LAST:event_CappuccinoActionPerformed

    private void MacchiatoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MacchiatoActionPerformed
        if(Macchiato.isSelected()){
            macchiatoSmallAdd.setIcon(activeAdd);
            macchiatoMediumAdd.setIcon(activeAdd);
            macchiatoLargeAdd.setIcon(activeAdd);
            macchiatoSmallSubtract.setIcon(activeSubtract);
            macchiatoMediumSubtract.setIcon(activeSubtract);
            macchiatoLargeSubtract.setIcon(activeSubtract);
        }else{
            macchiatoSmallAdd.setIcon(disabledAdd);
            macchiatoMediumAdd.setIcon(disabledAdd);
            macchiatoLargeAdd.setIcon(disabledAdd);
            macchiatoSmallSubtract.setIcon(disabledSubtract);
            macchiatoMediumSubtract.setIcon(disabledSubtract);
            macchiatoLargeSubtract.setIcon(disabledSubtract);
        }
    }//GEN-LAST:event_MacchiatoActionPerformed

    private void CaramelCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CaramelCActionPerformed
        if(CaramelC.isSelected()){
            caramelCSmallAdd.setIcon(activeAdd);
            caramelCMediumAdd.setIcon(activeAdd);
            caramelCLargeAdd.setIcon(activeAdd);
            caramelCSmallSubtract.setIcon(activeSubtract);
            caramelCMediumSubtract.setIcon(activeSubtract);
            caramelCLargeSubtract.setIcon(activeSubtract);
        }else{
            caramelCSmallAdd.setIcon(disabledAdd);
            caramelCMediumAdd.setIcon(disabledAdd);
            caramelCLargeAdd.setIcon(disabledAdd);
            caramelCSmallSubtract.setIcon(disabledSubtract);
            caramelCMediumSubtract.setIcon(disabledSubtract);
            caramelCLargeSubtract.setIcon(disabledSubtract);
        }
    }//GEN-LAST:event_CaramelCActionPerformed

    private void DecafDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DecafDActionPerformed
        if(DecafD.isSelected()){
            decafDSmallAdd.setIcon(activeAdd);
            decafDMediumAdd.setIcon(activeAdd);
            decafDLargeAdd.setIcon(activeAdd);
            decafDSmallSubtract.setIcon(activeSubtract);
            decafDMediumSubtract.setIcon(activeSubtract);
            decafDLargeSubtract.setIcon(activeSubtract);
        }else{
            decafDSmallAdd.setIcon(disabledAdd);
            decafDMediumAdd.setIcon(disabledAdd);
            decafDLargeAdd.setIcon(disabledAdd);
            decafDSmallSubtract.setIcon(disabledSubtract);
            decafDMediumSubtract.setIcon(disabledSubtract);
            decafDLargeSubtract.setIcon(disabledSubtract);
        }
    }//GEN-LAST:event_DecafDActionPerformed

    private void IcedCoffeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IcedCoffeeActionPerformed
        if(IcedCoffee.isSelected()){
            iceCoffeeSmallAdd.setIcon(activeAdd);
            iceCoffeeMediumAdd.setIcon(activeAdd);
            iceCoffeeLargeAdd.setIcon(activeAdd);
            iceCoffeeSmallSubtract.setIcon(activeSubtract);
            iceCoffeeMediumSubtract.setIcon(activeSubtract);
            iceCoffeeLargeSubtract.setIcon(activeSubtract);
        }else{
            iceCoffeeSmallAdd.setIcon(disabledAdd);
            iceCoffeeMediumAdd.setIcon(disabledAdd);
            iceCoffeeLargeAdd.setIcon(disabledAdd);
            iceCoffeeSmallSubtract.setIcon(disabledSubtract);
            iceCoffeeMediumSubtract.setIcon(disabledSubtract);
            iceCoffeeLargeSubtract.setIcon(disabledSubtract);
        }
    }//GEN-LAST:event_IcedCoffeeActionPerformed

    private void espressoMediumSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_espressoMediumSubtractMouseClicked
        if(Espresso.isSelected()) {
            setItem("Espresso M", 35.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_espressoMediumSubtractMouseClicked

    private void espresssoLargeAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_espresssoLargeAddMouseClicked
        if(Espresso.isSelected()) {
            setItem("Espresso L", 65.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_espresssoLargeAddMouseClicked

    private void espresssoLargeSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_espresssoLargeSubtractMouseClicked
        if(Espresso.isSelected()) {
            setItem("Espresso L", 65.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_espresssoLargeSubtractMouseClicked

    private void americanoMediumAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_americanoMediumAddMouseClicked
        if(Americano.isSelected()) {
            setItem("Americano M", 45.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_americanoMediumAddMouseClicked

    private void americanoMediumSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_americanoMediumSubtractMouseClicked
        if(Americano.isSelected()) {
            setItem("Americano M", 45.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_americanoMediumSubtractMouseClicked

    private void americanoLargeAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_americanoLargeAddMouseClicked
        if(Americano.isSelected()) {
            setItem("Americano L", 65.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_americanoLargeAddMouseClicked

    private void americanoLargeSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_americanoLargeSubtractMouseClicked
        if(Americano.isSelected()) {
            setItem("Americano L", 65.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_americanoLargeSubtractMouseClicked

    private void cappuccinoMediumAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cappuccinoMediumAddMouseClicked
        if(Cappuccino.isSelected()) {
            setItem("Cappuccino M", 47.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_cappuccinoMediumAddMouseClicked

    private void cappuccinoMediumSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cappuccinoMediumSubtractMouseClicked
        if(Cappuccino.isSelected()) {
            setItem("Cappuccino M", 47.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_cappuccinoMediumSubtractMouseClicked

    private void cappuccinoLargeAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cappuccinoLargeAddMouseClicked
        if(Cappuccino.isSelected()) {
            setItem("Cappuccino L", 47.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_cappuccinoLargeAddMouseClicked

    private void cappuccinoLargeSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cappuccinoLargeSubtractMouseClicked
        if(Cappuccino.isSelected()) {
            setItem("Cappuccino L", 47.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_cappuccinoLargeSubtractMouseClicked

    private void macchiatoMediumAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_macchiatoMediumAddMouseClicked
        if(Macchiato.isSelected()) {
            setItem("Caffe Macchiato M", 50.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_macchiatoMediumAddMouseClicked

    private void macchiatoMediumSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_macchiatoMediumSubtractMouseClicked
        if(Macchiato.isSelected()) {
            setItem("Caffe Macchiato M", 50.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_macchiatoMediumSubtractMouseClicked

    private void macchiatoLargeAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_macchiatoLargeAddMouseClicked
        if(Macchiato.isSelected()) {
            setItem("Caffe Macchiato L", 75.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_macchiatoLargeAddMouseClicked

    private void macchiatoLargeSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_macchiatoLargeSubtractMouseClicked
        if(Macchiato.isSelected()) {
            setItem("Caffe Macchiato L", 75.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_macchiatoLargeSubtractMouseClicked

    private void caramelCMediumAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_caramelCMediumAddMouseClicked
        if(CaramelC.isSelected()) {
            setItem("Caramel Cream M", 50.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_caramelCMediumAddMouseClicked

    private void caramelCMediumSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_caramelCMediumSubtractMouseClicked
        if(CaramelC.isSelected()) {
            setItem("Caramel Cream M", 50.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_caramelCMediumSubtractMouseClicked

    private void caramelCLargeAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_caramelCLargeAddMouseClicked
        if(CaramelC.isSelected()) {
            setItem("Caramel Cream L", 75.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_caramelCLargeAddMouseClicked

    private void caramelCLargeSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_caramelCLargeSubtractMouseClicked
        if(CaramelC.isSelected()) {
            setItem("Caramel Cream L", 75.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_caramelCLargeSubtractMouseClicked

    private void decafDMediumAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_decafDMediumAddMouseClicked
        if(DecafD.isSelected()) {
            setItem("Decaf Delight M", 65.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_decafDMediumAddMouseClicked

    private void decafDMediumSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_decafDMediumSubtractMouseClicked
        if(DecafD.isSelected()) {
            setItem("Decaf Delight M", 65.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_decafDMediumSubtractMouseClicked

    private void decafDLargeAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_decafDLargeAddMouseClicked
        if(DecafD.isSelected()) {
            setItem("Decaf Delight L", 105.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_decafDLargeAddMouseClicked

    private void decafDLargeSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_decafDLargeSubtractMouseClicked
        if(DecafD.isSelected()) {
            setItem("Decaf Delight L", 105.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_decafDLargeSubtractMouseClicked

    private void iceCoffeeMediumAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iceCoffeeMediumAddMouseClicked
        if(IcedCoffee.isSelected()) {
            setItem("Iced Coffee M", 75.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_iceCoffeeMediumAddMouseClicked

    private void iceCoffeeMediumSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iceCoffeeMediumSubtractMouseClicked
        if(IcedCoffee.isSelected()) {
            setItem("Iced Coffee M", 75.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_iceCoffeeMediumSubtractMouseClicked

    private void iceCoffeeLargeAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iceCoffeeLargeAddMouseClicked
        if(IcedCoffee.isSelected()) {
            setItem("Iced Coffee L", 125.00, true);
            setOrderTable();
        }
    }//GEN-LAST:event_iceCoffeeLargeAddMouseClicked

    private void iceCoffeeLargeSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iceCoffeeLargeSubtractMouseClicked
        if(IcedCoffee.isSelected()) {
            setItem("Iced Coffee L", 125.00, false);
            setOrderTable();
        }
    }//GEN-LAST:event_iceCoffeeLargeSubtractMouseClicked

    private void croissantAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_croissantAddMouseClicked
        setItem("Croissant", 55.00, true);
        setOrderTable();
    }//GEN-LAST:event_croissantAddMouseClicked

    private void croissantSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_croissantSubtractMouseClicked
        setItem("Croissant", 55.00, false);
        setOrderTable();
    }//GEN-LAST:event_croissantSubtractMouseClicked

    private void cheeseCakeAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cheeseCakeAddMouseClicked
        setItem("Cheese Cake", 50.00, true);
        setOrderTable();
    }//GEN-LAST:event_cheeseCakeAddMouseClicked

    private void cheeseCakeSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cheeseCakeSubtractMouseClicked
        setItem("Cheese Cake", 50.00, false);
        setOrderTable();
    }//GEN-LAST:event_cheeseCakeSubtractMouseClicked

    private void browniesAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_browniesAddMouseClicked
        setItem("Brownies", 65.00, true);
        setOrderTable();
    }//GEN-LAST:event_browniesAddMouseClicked

    private void browniesSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_browniesSubtractMouseClicked
        setItem("Brownies", 65.00, false);
        setOrderTable();
    }//GEN-LAST:event_browniesSubtractMouseClicked

    private void strawberryWAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_strawberryWAddMouseClicked
        setItem("Strawberry Waffle", 75.00, true);
        setOrderTable();
    }//GEN-LAST:event_strawberryWAddMouseClicked

    private void strawberryWSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_strawberryWSubtractMouseClicked
        setItem("Strawberry Waffle", 75.00, false);
        setOrderTable();
    }//GEN-LAST:event_strawberryWSubtractMouseClicked

    private void chocoMAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_chocoMAddMouseClicked
        setItem("Chocolate Muffin", 99.00, true);
        setOrderTable();
    }//GEN-LAST:event_chocoMAddMouseClicked

    private void chocoMSubtractMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_chocoMSubtractMouseClicked
        setItem("Chocolate Muffin", 99.00, false);
        setOrderTable();
    }//GEN-LAST:event_chocoMSubtractMouseClicked

    private void confirm1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirm1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_confirm1ActionPerformed

    private void confirm1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_confirm1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_confirm1MouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox Americano;
    private javax.swing.JCheckBox Cappuccino;
    private javax.swing.JCheckBox CaramelC;
    private javax.swing.JCheckBox DecafD;
    private javax.swing.JCheckBox Espresso;
    private javax.swing.JCheckBox IcedCoffee;
    private javax.swing.JCheckBox Macchiato;
    private javax.swing.ButtonGroup americanoBtns;
    private javax.swing.JLabel americanoLargeAdd;
    private javax.swing.JLabel americanoLargeSubtract;
    private javax.swing.JLabel americanoMediumAdd;
    private javax.swing.JLabel americanoMediumSubtract;
    private javax.swing.JLabel americanoPriceLarge;
    private javax.swing.JLabel americanoPriceMedium;
    private javax.swing.JLabel americanoPriceSmall;
    private javax.swing.JLabel americanoSmallAdd;
    private javax.swing.JLabel americanoSmallSubtract;
    private javax.swing.JButton back;
    private javax.swing.JLabel backGround;
    private javax.swing.JLabel brownies;
    private javax.swing.JLabel browniesAdd;
    private javax.swing.JLabel browniesSubtract;
    private javax.swing.ButtonGroup cCreamBtns;
    private javax.swing.ButtonGroup cMacchiatoBtns;
    private javax.swing.ButtonGroup cappuccinoBtns;
    private javax.swing.JLabel cappuccinoLargeAdd;
    private javax.swing.JLabel cappuccinoLargeSubtract;
    private javax.swing.JLabel cappuccinoMediumAdd;
    private javax.swing.JLabel cappuccinoMediumSubtract;
    private javax.swing.JLabel cappuccinoPriceLarge;
    private javax.swing.JLabel cappuccinoPriceMedium;
    private javax.swing.JLabel cappuccinoPriceSmall;
    private javax.swing.JLabel cappuccinoSmallAdd;
    private javax.swing.JLabel cappuccinoSmallSubtract;
    private javax.swing.JLabel caramelCLargeAdd;
    private javax.swing.JLabel caramelCLargeSubtract;
    private javax.swing.JLabel caramelCMediumAdd;
    private javax.swing.JLabel caramelCMediumSubtract;
    private javax.swing.JLabel caramelCPriceLarge;
    private javax.swing.JLabel caramelCPriceMedium;
    private javax.swing.JLabel caramelCPriceSmall;
    private javax.swing.JLabel caramelCSmallAdd;
    private javax.swing.JLabel caramelCSmallSubtract;
    private javax.swing.JLabel cash;
    private javax.swing.JLabel cheeseCake;
    private javax.swing.JLabel cheeseCakeAdd;
    private javax.swing.JLabel cheeseCakeSubtract;
    private javax.swing.JLabel chocoM;
    private javax.swing.JLabel chocoMAdd;
    private javax.swing.JLabel chocoMSubtract;
    private javax.swing.JPanel choicePanel;
    private javax.swing.JButton confirm;
    private javax.swing.JButton confirm1;
    private javax.swing.JLabel croissant;
    private javax.swing.JLabel croissantAdd;
    private javax.swing.JLabel croissantSubtract;
    private javax.swing.ButtonGroup dDelightBtns;
    private javax.swing.JLabel decafDLargeAdd;
    private javax.swing.JLabel decafDLargeSubtract;
    private javax.swing.JLabel decafDMediumAdd;
    private javax.swing.JLabel decafDMediumSubtract;
    private javax.swing.JLabel decafDPriceLarge;
    private javax.swing.JLabel decafDPriceMedium;
    private javax.swing.JLabel decafDPriceSmall;
    private javax.swing.JLabel decafDSmallAdd;
    private javax.swing.JLabel decafDSmallSubtract;
    private javax.swing.ButtonGroup espressoBtns;
    private javax.swing.JLabel espressoMediumAdd;
    private javax.swing.JLabel espressoMediumSubtract;
    private javax.swing.JLabel espressoPriceLarge;
    private javax.swing.JLabel espressoPriceMedium;
    private javax.swing.JLabel espressoPriceSmall;
    private javax.swing.JLabel espressoSmallAdd;
    private javax.swing.JLabel espressoSmallSubtract;
    private javax.swing.JLabel espresssoLargeAdd;
    private javax.swing.JLabel espresssoLargeSubtract;
    private javax.swing.JPanel finalMoney;
    private javax.swing.JLabel gcash;
    private javax.swing.JLabel header;
    private javax.swing.JLabel headerPriceLarge;
    private javax.swing.JLabel headerPriceMedium;
    private javax.swing.JLabel headerPriceSmall;
    private javax.swing.ButtonGroup iCoffeeBtns;
    private javax.swing.JLabel iceCoffeeLargeAdd;
    private javax.swing.JLabel iceCoffeeLargeSubtract;
    private javax.swing.JLabel iceCoffeeMediumAdd;
    private javax.swing.JLabel iceCoffeeMediumSubtract;
    private javax.swing.JLabel iceCoffeePriceLarge;
    private javax.swing.JLabel iceCoffeePriceMedium;
    private javax.swing.JLabel iceCoffeePriceSmall;
    private javax.swing.JLabel iceCoffeeSmallAdd;
    private javax.swing.JLabel iceCoffeeSmallSubtract;
    private javax.swing.JPanel itemSelection;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel macchiatoLargeAdd;
    private javax.swing.JLabel macchiatoLargeSubtract;
    private javax.swing.JLabel macchiatoMediumAdd;
    private javax.swing.JLabel macchiatoMediumSubtract;
    private javax.swing.JLabel macchiatoPriceLarge;
    private javax.swing.JLabel macchiatoPriceMedium;
    private javax.swing.JLabel macchiatoPriceSmall;
    private javax.swing.JLabel macchiatoSmallAdd;
    private javax.swing.JLabel macchiatoSmallSubtract;
    private javax.swing.JLabel menuLabell;
    private javax.swing.JPanel menuPanel;
    private javax.swing.JTextField money;
    private javax.swing.JButton nextButton;
    private javax.swing.JLabel orderBg;
    private javax.swing.JPanel orderPanel;
    private javax.swing.JTable orders;
    private javax.swing.JTable ordersInfo;
    private javax.swing.JLabel paymaya;
    private javax.swing.JLabel saved;
    private javax.swing.JLabel savedText;
    private javax.swing.JPanel selectPayment;
    private javax.swing.JLabel strawberryW;
    private javax.swing.JLabel strawberryWAdd;
    private javax.swing.JLabel strawberryWSubtract;
    private javax.swing.JCheckBox takeOut;
    private javax.swing.JLabel totalCheck;
    private javax.swing.JLabel totalText;
    private javax.swing.JLabel year;
    // End of variables declaration//GEN-END:variables
}
